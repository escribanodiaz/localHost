$("document").ready(function() {
  alert("Ex1");
  var mensaje1 = $("#username").attr("placeholder");
  $("#username").val(mensaje1);

  var mensaje2 = $("#email").attr("placeholder");
  $("#email").val(mensaje2);
});
