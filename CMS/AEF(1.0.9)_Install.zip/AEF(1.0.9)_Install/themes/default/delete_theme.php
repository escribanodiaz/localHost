<?php

//Right now no function required
function delete_theme(){



}

?>