<?php

function stats_theme(){

	//The header
	aefheader('Board Statistics');
	
	
	//The defualt footers
	aeffooter();

}

?>