This is a beatiful smiley pack at:
http://gnome-look.org/content/show.php/gaim+-+crystal+smile+-+emoticons?content=32559 
