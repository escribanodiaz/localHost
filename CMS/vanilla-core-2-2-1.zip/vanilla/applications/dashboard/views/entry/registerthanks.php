<?php if (!defined('APPLICATION')) exit(); ?>
<div class="Center SplashInfo">
    <h1><?php echo t('Thank You!'); ?></h1>

    <div id="Message">
        <?php echo t('Your application will be reviewed by an administrator. You will be notified by email if your application is approved.'); ?>
    </div>
</div>
