<?php if (!defined('APPLICATION')) exit(); ?>
<h1><?php echo t("Reset my password") ?></h1>
<div class="P">
    <p><?php echo t('A message has been sent to your email address with password reset instructions.'); ?></p>
</div>
