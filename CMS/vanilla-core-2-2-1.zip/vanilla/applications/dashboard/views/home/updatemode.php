<?php if (!defined('APPLICATION')) exit(); ?>

<div class="SplashInfo">
    <h1><?php echo t('Maintenance Mode'); ?></h1>

    <p><?php echo t('The site is currently undergoing maintenance.'); ?></p>
</div>
<!-- Domain: <?php echo Gdn::config('Garden.Domain', ''); ?> -->
