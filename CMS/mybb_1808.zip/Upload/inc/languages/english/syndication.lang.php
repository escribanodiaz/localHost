<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['all_forums'] = "All Forums";
$l['forum'] = "Forum:";
$l['posted_by'] = "Posted By:";
$l['on'] = "on";
$l['portal'] = "Portal";

