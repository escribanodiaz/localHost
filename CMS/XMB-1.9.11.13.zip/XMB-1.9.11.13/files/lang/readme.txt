XMB 1.9.11+ Translation System Tips

Starting with XMB version 1.9.11, files named *.lang.php
are no longer saved in the /lang/ subdirectory.  Visit
the Administration Panel of your board to upload the new files.

Note: If you are doing an upgrade from any version less than 1.9.8
then the upgrade script will need to use the language files one last time.
Do use the new English.lang.php file because it is saved during the upgrade.

The latest language translation files can be found at:

svn://svn.code.sf.net/p/xmb-forum/code/xmb19x/branches/lang