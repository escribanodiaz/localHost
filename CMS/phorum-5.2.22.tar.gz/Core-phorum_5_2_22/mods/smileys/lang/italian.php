<?php
$PHORUM["DATA"]["LANG"]["mod_smileys"] = array(
    'smiley'        => 'Inserisci un icona (smileys)',
    'subjectsmiley' => 'Inserisci un icona nel messaggio',
    'smileys help'  => 'Smileys (istruzioni uso)',

    # Text for the smileys disable option in the posting editor.
    'disable'      => 'Disable smileys for this message'
);
?>
