<?php
$PHORUM["DATA"]["LANG"]["mod_smileys"] = array(
    'smiley'        => 'Vlo�it smajl�ka',
    'subjectsmiley' => 'Vlo�it smajl�ka do p�edm�tu',
    'smileys help'  => 'Smajl�ky n�pov�da',

    # Text for the smileys disable option in the posting editor.
    'disable'      => 'Disable smileys for this message'
);
?>
