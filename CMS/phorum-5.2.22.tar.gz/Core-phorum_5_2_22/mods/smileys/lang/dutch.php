<?php
$PHORUM["DATA"]["LANG"]["mod_smileys"] = array(
    'smiley'        => 'Smiley invoegen',
    'subjectsmiley' => 'Smiley invoegen in het onderwerp',
    'smileys help'  => 'Smileys help',

    # Text for the smileys disable option in the posting editor.
    'disable'      => 'Smileys uitschakelen voor dit bericht'
);
?>
