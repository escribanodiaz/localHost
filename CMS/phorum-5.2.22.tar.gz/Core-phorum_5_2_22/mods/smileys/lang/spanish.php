<?php
$PHORUM["DATA"]["LANG"]["mod_smileys"] = array(
    'smiley'        => 'Insertar smiley',
    'subjectsmiley' => 'Insertar smiley en el asunto',
    'smileys help'  => 'Ayuda Smileys',

    # Text for the smileys disable option in the posting editor.
    'disable'      => 'Disable smileys for this message'
);
?>
