<?php
$PHORUM["DATA"]["LANG"]["mod_smileys"] = array(
    'smiley'        => 'Insert smiley',
    'subjectsmiley' => 'Insert smiley into the subject',
    'smileys help'  => 'Smileys help',

    # Text for the smileys disable option in the posting editor.
    'disable'      => 'Disable smileys for this message'
);
?>
